package com.example.quizapp19


data class Category(
    val name: String,
    val id: Int,
    val imageResourceId: Int = R.drawable.default_category_image
)

