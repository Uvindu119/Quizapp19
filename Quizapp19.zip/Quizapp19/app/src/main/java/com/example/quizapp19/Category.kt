package com.example.quizapp19

data class Category(var name: String,var id: Int) {
    var setNumber: Int = 1
}