package com.example.quizapp19

data class Category(var name: String) {
    var id: Int = 0
}